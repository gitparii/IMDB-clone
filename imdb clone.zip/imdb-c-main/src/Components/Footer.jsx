import React from 'react'

const Footer = () => {
  return (
   <div className="footer">
    Created by : Muzamal Ali
   </div>
  )
}

export default Footer