import React from 'react'

const MovieDetails = () => {
  return (
    <div>MovieDetails</div>
  )
}

export default MovieDetails