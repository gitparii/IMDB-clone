# imdb-c
This is an most likely imdb clone project created with help of React JS along with some taste of Material UI for designing of UI
